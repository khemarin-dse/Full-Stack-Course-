let studentName = prompt("Enter student name:");
let studentScore = Number(prompt("Enter student score:"));

let grade;

if (studentScore >= 90) {
    grade = "A";
} else if (studentScore >= 80) {
    grade = "B";
} else if (studentScore >= 70) {
    grade = "C";
} else {
    grade = "Fail";
}

alert(studentName + " got grade " + grade);
console.log(studentName + " got grade " + grade);